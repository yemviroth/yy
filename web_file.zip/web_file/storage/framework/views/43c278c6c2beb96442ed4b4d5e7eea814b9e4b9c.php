


<div class="pt-2 d-block d-md-none d-lg-none"></div>
<div class="container-fluid">
<div class="d-sm-none pt-5">
  <div class="row text-kh">
    <?php $__currentLoopData = $cates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <div class="col-4 col-sm-4 border">
          <a class="list-horizon" href="<?php echo e(route('category.show', $cate->cateId)); ?>"><strong><?php echo e($cate->cateName); ?></strong></a>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>           
    </div>
  </diV>
</div><?php /**PATH C:\xampp\htdocs\tp\web_file\resources\views/layouts/mobile-cate.blade.php ENDPATH**/ ?>