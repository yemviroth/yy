<?php $__env->startSection('content'); ?>



<div class="w-100 d-none d-md-block pt-5"></div>
<section class="" style="background: #fff">
  <div class="pt-4 d-none d-lg-block"></div>
  <div class="header-title pt-4 text-center"><?php echo e($pros[0]->cateName); ?></div>
  <div class="text-center pt-2">

  
  <?php $__currentLoopData = $pros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pross): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $__currentLoopData = $pross->subCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <li class="list-horizon d-inline pl-4"><a href="<?php echo e(url("/category/$pross->cateId/subCates/$subcate->subCateId")); ?>"><?php echo e($subcate->subCateName); ?></a></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    

    
  </div>


  <div class="wrapper">

    <div class="container-fluid">
      <div class="row pt-4">
        <div class="col-md-6">
          <?php $__currentLoopData = $pros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pross): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="text-kh">
            <p class="font-weight-bold">ចំនួនផលិតផល : <span class="badge badge-primary badge-pill"><?php echo e($pros[0]->products->count()); ?></span></p>
          </div>


          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="d-none d-md-block d-lg-block col-md-6 text-right text-kh">
          <strong>តម្រៀប :</strong> <a href="<?php echo e(url()->current()); ?>/?sort=1">ផលិតផលថ្មី </a> | <a href="<?php echo e(url()->current()); ?>/?sort=2">ឈ្មោះផលិតផល </a>| <a href="<?php echo e(url()->current()); ?>/?sort=3">តំលៃខ្ពស់ </a>| <a href="<?php echo e(url()->current()); ?>/?sort=4">តំលៃទាប </a>
        </div>

        <div class="d-none d-sm-none d-xs-block col-md-6 col-sm-12 text-right text-kh">
          <div class="input-group mb-3">
            <!--   <div class="input-group-prepend">
                  <label class="input-group-text" for="sort">តម្រៀប</label>
                </div> -->
            <select name="sort" class="custom-select" id="sort" onchange="location='<?php echo e(url()->current()); ?>/?sort='+ this.value">
              <option value="0" selected>--តម្រៀប--</option>
              <option value="1" <?php if(request()->input('sort')==1): ?> selected <?php endif; ?>>ផលិតផលថ្មី</option>
              <option value="2" <?php if(request()->input('sort')==2): ?> selected <?php endif; ?>>ឈ្មោះផលិតផល</option>
              <option value="3" <?php if(request()->input('sort')==3): ?> selected <?php endif; ?>>តំលៃខ្ពស់</option>
              <option value="4" <?php if(request()->input('sort')==4): ?> selected <?php endif; ?>>តំលៃទាប</option>
            </select>
            
          </div>
        </div>
      </div>
     
<?php if($pross->products->count()>0): ?>
      <div class="row">
        <?php $__currentLoopData = $pros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pross): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $__currentLoopData = $pross->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-sm-4 col-md-4 col-6 mt-3">

          <div class="">
            <div class="content">
              <a href="<?php echo e(route('productdetail.show',$pro->proId)); ?>" target="">
                <div class="content-overlay d-none d-md-block"></div>
                <img class="content-image img-fluid" src="<?php echo e(asset('images/product/'.$pro->proImage)); ?>">
                <div class="content-details fadeIn-top float-left d-none d-md-block">
                  <?php if($pro->proIsInStock=='No'): ?>
                  <h5><span class="p-1 badge badge-light mb-4 ">មិនមានក្នុងស្តុក</span></h5>
                  <?php endif; ?>
                   <h6><?php echo $pro->proName; ?></h6>
                 
                   <?php if($pro->proColor1!=""): ?><span class="badge pl-4 border" style="background-color:<?php echo $pro->proColor1; ?>;">  </span><?php endif; ?>
                    <?php if($pro->proColor2!=""): ?><span class="badge pl-4 border" style="background-color:<?php echo $pro->proColor2; ?>;">  </span><?php endif; ?>
                    <?php if($pro->proColor3!=""): ?><span class="badge pl-4 border" style="background-color:<?php echo $pro->proColor3; ?>;">  </span><?php endif; ?>
                    <?php if($pro->proColor4!=""): ?><span class="badge pl-4 border" style="background-color:<?php echo $pro->proColor4; ?>;">  </span><?php endif; ?>
                    <?php if($pro->proColor5!=""): ?><span class="badge pl-4 border" style="background-color:<?php echo $pro->proColor5; ?>;">  </span><?php endif; ?>
                  <p class="price">$<?php echo e($pro->proPrice); ?></p>
                  <p><?php echo $pro->proTextIntro; ?></p>

                </div>


                <div class="d-block d-lg-none">
                  <div class="text-under-product">

                    <h6><?php echo $pro->proName; ?></h6>
                  
                    <?php if($pro->proColor1!=""): ?><span class="badge pl-4 border" style="background-color:<?php echo $pro->proColor1; ?>;">  </span><?php endif; ?>
                    <?php if($pro->proColor2!=""): ?><span class="badge pl-4 border" style="background-color:<?php echo $pro->proColor2; ?>;">  </span><?php endif; ?>
                    <?php if($pro->proColor3!=""): ?><span class="badge pl-4 border" style="background-color:<?php echo $pro->proColor3; ?>;">  </span><?php endif; ?>
                    <?php if($pro->proColor4!=""): ?><span class="badge pl-4 border" style="background-color:<?php echo $pro->proColor4; ?>;">  </span><?php endif; ?>
                    <?php if($pro->proColor5!=""): ?><span class="badge pl-4 border" style="background-color:<?php echo $pro->proColor5; ?>;">  </span><?php endif; ?>
                    
                    <p class="price">$<?php echo e($pro->proPrice); ?> <?php if($pro->proIsInStock=='No'): ?>
                    <span class="badge badge-dark mb-2 ml-5">មិនមានក្នុងស្តុក</span>
                    <?php endif; ?></p>
                    <p><?php echo str_limit($pro->proTextIntro, 60); ?></p>

                  </div>
                </div>

              </a>
            </div>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
      <img class="w-100" src="<?php echo e(asset('images/404.png')); ?>" alt="">
    <?php endif; ?>
      </div>
     
</section>
</div>
</div>
</section>






<?php $__env->stopSection(); ?>

<!--  <script type="text/javascript">
        $(document).ready(function () {
           $('#sort').change(function () {
             var sortt = $(this).val();

             $('#subCategory').find('option').not(':first').remove();

             $.ajax({
                url:'<?php echo e(route('categories','')); ?>/?'+sortt,
                type:'get',
                dataType:'json',
                success:function (response) {
                    var len = 0;
                    if (response.data != null) {
                        len = response.data.length;
                    }

                    if (len>0) {
                        for (var i = 0; i<len; i++) {
                             var id = response.data[i].subCateId;
                             var name = response.data[i].subCateName;

                             var option = "<option value='"+id+"'>"+name+"</option>"; 

                             $("#subCategory").append(option);
                        }
                    }
                }
             })
           });
        });
    </script> -->
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tp\web_file\resources\views/category/show.blade.php ENDPATH**/ ?>