<?php $__env->startSection('content'); ?>



<!-- <?php if($message = Session::get('success')): ?>
<div id="malert" class="alert alert-success alert-dismissible fade show" role="alert"><?php echo e($message); ?>

    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>

<?php endif; ?> -->



<div class="">
    <div class="">



        <div class="">
            <div class=" ml-0 mr-0 pt-2 pb-1">
                <a href="<?php echo e(route('brand.create')); ?>" class="btn btn-success btn-sm"><i class="fas fa-plus-square"></i> បន្ថែមដំណាងចែកចាយ</a>

            </div>

        </div>

        <div class="">
            <div class="card">
                <H6 class="card-header bg-dark text-light">
                    <i class="fas fa-users"></i><span class="ml-2">បញ្ជីដំណាងចែកចាយ</span>

                </H6>
                <div class="card-body shadow">
                    <div class="table-responsive">
                        <table class="table table-border datatable" style="font-size:14px;" id="">

                            <thead class="">
                                <th>រូបថត</th>
                                <th>ឈ្មោះដំណាងចែកចាយ</th>
                                <th>ទីតាំង / ខេត្ត</th>
                                <th>អស័យដ្ឋាន</th>
                                <th>លេខទូរស័ព្ទ</th>
                                <th>FB</th>
                                <th>IG</th>
                                <th>សកម្មភាព</th>

                            </thead>
                            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tbody id="">
                                <tr style="">
                                    <td><img class="rounded-circle" style="width: 80px;height:80px;" src="<?php if($brand->dsPhoto!=''): ?><?php echo e(asset('images/profile/'.$brand->dsPhoto)); ?> <?php else: ?> <?php echo e(asset('images/profile/noImg.png')); ?><?php endif; ?>" alt=""></td>
                                    <td><?php echo e($brand->dsName); ?></td>
                                    <td><?php echo e($brand->dsLocation); ?></td>
                                    <td><?php echo e($brand->dsAddress); ?></td>
                                    <td><?php echo e($brand->dsPhone); ?></td>
                                    <td><?php echo e($brand->dsFb); ?></td>
                                    <td><?php echo e($brand->dsIg); ?></td>


                                    <td>
                                        <form action="<?php echo e(route('brand.destroy',$brand->id)); ?>" method="POST">

                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>

                                            <a style="" class="btn btn-sm btn-primary" href="<?php echo e(route('brand.edit', $brand->id)); ?>"><i class="fas fa-edit"></i></a>
                                            <button style="" name="btndelete" data-toggle="tooltip" title="Delete" type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this items : <?php echo e($brand->bsName); ?> ?');"><i class="fas fa-trash"></i></button>
                                        </form>
                                    </td>

                                </tr>
                            </tbody>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<script>
    $(document).ready(function() {
        $("#myInput").on("keyup", function() {
            var value = $(this).val().toLowerCase();
            $("#myTable tr").filter(function() {
                $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
            });
        });
    });
</script>
<?php echo $__env->make('layouts.dash.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tp\web_file\resources\views/brand/list.blade.php ENDPATH**/ ?>