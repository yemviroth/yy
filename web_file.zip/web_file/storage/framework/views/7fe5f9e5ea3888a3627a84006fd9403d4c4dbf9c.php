<?php $__env->startSection('content'); ?>

<!-- slide -->

<div class="wrapper">

  <div class="container-fluid">
    <div class="d-none d-sm-block d-md-block" style="padding-top: 100px;"></div>
    <section class="" style="background: #fff;">

      <div class="header-title text-center p-3">ស្វែងរកផលិតផល</div>

      <form action="<?php echo e(route('search')); ?>" method="Get" class="form-group pt-2 mb-5">
        <div class="row">
          <div class="col-md-10 col-12 col-sm-12 mb-2">
            <?php echo csrf_field(); ?>
            <input type="text" value="<?php echo e(request()->input('search')); ?>" name="search" class="form-control" placeholder="ស្វែងរក​">
          </div>
          <div class="col-md-2 col-12 col-sm-12 mb-2">
            <button role="submit" class="btn btn-dark w-100"><i class="fas fa-search"></i></button>
          </div>
        </div>
      </form>


      <div class="row pt-1">
        <div class="col-md-6 col-sm-12 ">


          <p class="font-weight-bold text-kh">លទ្ធផលសម្រាប់ <?php echo e(request()->input('search')); ?> មាន: <span class="badge badge-primary badge-pill"><?php echo e($pros->count()); ?></span></p>



        </div>
        <div class="d-none d-md-block d-lg-block col-md-6 col-sm-12 text-right text-kh">
          <strong>តម្រៀប :</strong> <a href="<?php echo e(url()->full()); ?>&sort=1">ផលិតផលថ្មី </a> | <a href="<?php echo e(url()->full()); ?>&sort=2">ឈ្មោះផលិតផល </a>| <a href="<?php echo e(url()->full()); ?>&sort=3">តំលៃខ្ពស់ </a>| <a href="<?php echo e(url()->full()); ?>&sort=4">តំលៃទាប </a>
        </div>

        <div class="d-none d-sm-none d-xs-block col-md-6 col-sm-12 text-right text-kh">
          <div class="input-group mb-3">
            <div class="input-group-prepend">
              <label class="input-group-text" for="sort">តម្រៀប</label>
            </div>
            <select name="sort" class="custom-select" id="sort" onchange="location='<?php echo e(url()->full()); ?>&sort='+ this.value">
              <option value="1" <?php if(request()->input('sort')==1): ?> selected <?php endif; ?>>ផលិតផលថ្មី</option>
              <option value="2" <?php if(request()->input('sort')==2): ?> selected <?php endif; ?>>ឈ្មោះផលិតផល</option>
              <option value="3" <?php if(request()->input('sort')==3): ?> selected <?php endif; ?>>តំលៃខ្ពស់</option>
              <option value="4" <?php if(request()->input('sort')==4): ?> selected <?php endif; ?>>តំលៃទាប</option>
            </select>
          </div>
        </div>



      </div>

      <div class="row border">
        <?php if($pros->count()>0): ?>
        <?php $__currentLoopData = $pros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="col-sm-4 col-md-4 col-6 mt-3">

          <div class="">
            <div class="content">
              <div class="">
                <a href="<?php echo e(route('productdetail.show',$pro->proId)); ?>" target="">
                  <div class="content-overlay d-none d-md-block"></div>
                  <img class="content-image img-fluid" src="<?php echo e(asset('images/product/'.$pro->proImage)); ?>">
                  <div class="content-details fadeIn-top float-left d-none d-md-block">
                    <?php if($pro->proIsInStock=='No'): ?>
                    <span class="badge badge-light mb-4">SOLDOUT</span>
                    <?php endif; ?>
                    <h6><?php echo $pro->proName; ?></h6>
                    <?php if($pro->proColor1!=""): ?><span class="badge pl-4  border" style="background-color:<?php echo $pro->proColor1; ?>;">  </span><?php endif; ?>
                    <?php if($pro->proColor2!=""): ?><span class="badge pl-4  border" style="background-color:<?php echo $pro->proColor2; ?>;">  </span><?php endif; ?>
                    <?php if($pro->proColor3!=""): ?><span class="badge pl-4  border" style="background-color:<?php echo $pro->proColor3; ?>;">  </span><?php endif; ?>
                    <?php if($pro->proColor4!=""): ?><span class="badge pl-4  border" style="background-color:<?php echo $pro->proColor4; ?>;">  </span><?php endif; ?>
                    <?php if($pro->proColor5!=""): ?><span class="badge pl-4  border" style="background-color:<?php echo $pro->proColor5; ?>;">  </span><?php endif; ?>

                    <p class="price">$<?php echo e($pro->proPrice); ?></p>
                    <p><?php echo $pro->proTextIntro; ?></p>
                  </div>
              </div>


              <div class="d-block d-md-none">
                <div class="text-under-product">

                    <div class="pt-3">

                    <?php if($pro->proColor1!=""): ?><span class="badge pl-4  border" style="background-color:<?php echo $pro->proColor1; ?>;">  </span><?php endif; ?>
                    <?php if($pro->proColor2!=""): ?><span class="badge pl-4  border" style="background-color:<?php echo $pro->proColor2; ?>;">  </span><?php endif; ?>
                    <?php if($pro->proColor3!=""): ?><span class="badge pl-4  border" style="background-color:<?php echo $pro->proColor3; ?>;">  </span><?php endif; ?>
                    <?php if($pro->pror4!=""): ?><span class="badge pl-4  border" style="background-color:<?php echo $pro->proColor4; ?>;">  </span><?php endif; ?>
                    <?php if($pro->proColor5!=""): ?><span class="badge pl-4  border" style="background-color:<?php echo $pro->proColor5; ?>;">  </span><?php endif; ?>

          
                    </div>
                  <h6><?php echo $pro->proName; ?></h6>
                  <?php if($pro->proIsInStock=='No'): ?>
                  <span class="badge badge-dark mb-2">SOLDOUT</span>
                  <?php endif; ?>
                  <p class="price">$<?php echo e($pro->proPrice); ?></p>
                  <p><?php echo e(str_limit($pro->proTextIntro, 60)); ?></p>

                </div>
              </div>

              </a>
            </div>
          </div>
        </div>


        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        <img class="w-100" src="<?php echo e(asset('images/404.png')); ?>" alt="">
      <?php endif; ?>
      </div>
    </section>
  </div>
</div>
</section>
</div>
</div>








<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tp\web_file\resources\views/productdetail/search.blade.php ENDPATH**/ ?>