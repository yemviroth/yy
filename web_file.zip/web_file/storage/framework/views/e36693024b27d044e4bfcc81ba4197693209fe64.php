<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-xl-3 col-md-6">
        <div class="card bg-info text-white mb-4">


            <div class="card-body p-5">
                <div class="d-flex">
                    Products Category <span class="  ml-auto justify-content-end">
                      
                        <h4><?php echo e($cates->count()); ?></h4>
                    </span>
                </div>

            </div>

            <div class="card-footer d-flex align-items-center justify-content-between">
                <a class="small text-white stretched-link" href="<?php echo e(route('category.list')); ?>">View Details</a>
                <div class="small text-white"><i class="fas fa-angle-right"></i></div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6">
        <div class="card bg-success text-white mb-4">


            <div class="card-body p-5">
                <div class="d-flex">
                    Products <span class="  ml-auto justify-content-end">
                        <h4><?php echo e($pros); ?></h4>
                    </span>
                </div>

            </div>

            <div class="card-footer d-flex align-items-center justify-content-between">
                <a class="small text-white stretched-link" href="<?php echo e(route('productdetail.list')); ?>">View Details</a>
                <div class="small text-white"><i class="fas fa-angle-right"></i></div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6">
        <div class="card bg-primary text-white mb-4">


            <div class="card-body p-5">
                <div class="d-flex">
                    Distributor <span class="  ml-auto justify-content-end">
                        <h4><?php echo e($brands->count()); ?></h4>
                    </span>
                </div>

            </div>

            <div class="card-footer d-flex align-items-center justify-content-between">
                <a class="small text-white stretched-link" href="<?php echo e(route('brand.list')); ?>">View Details</a>
                <div class="small text-white"><i class="fas fa-angle-right"></i></div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6">
        <div class="card bg-danger text-white mb-4">
            <div class="card-body p-5">
                <div class="d-flex">
                    Users <span class="ml-auto justify-content-end">
                        <h4><?php echo e($users->count()); ?></h4>
                    </span>
                </div>

            </div>
            <div class="card-footer d-flex align-items-center justify-content-between">
                <a class="small text-white stretched-link" href="<?php echo e(route('user.index')); ?>">View Details</a>
                <div class="small text-white"><i class="fas fa-angle-right"></i></div>
            </div>
        </div>
    </div>
</div>
<div class="row">

<div class="col-xl-8" style="font-size:13px">
        <div class="card">
            <div class="card-header bg-dark text-light">
                <i class="fas fa-users"></i><span class="ml-2">Distributor List</span>

            </div>
            <div class="card-body shadow">
                <div class="table-responsive">
                    <table class="table table-border datatable" style="" id="">

                        <thead class="">
                            <th>Distributor Name</th>
                            <th>Location</th>
                            <th>Address</th>
                            <th>Phone</th>
                            <th>FB</th>
                            <th>IG</th>
                            <th>Action</th>

                        </thead>
                        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tbody id="">
                            <tr style="">
                                <td><?php echo e($brand->dsName); ?></td>
                                <td><?php echo e($brand->dsLocation); ?></td>
                                <td><?php echo e($brand->dsAddress); ?></td>
                                <td><?php echo e($brand->dsPhone); ?></td>
                                <td><?php echo e($brand->dsFb); ?></td>
                                <td><?php echo e($brand->dsIg); ?></td>


                                <td>
                                    <form action="<?php echo e(route('brand.destroy',$brand->id)); ?>" method="POST">

                                        <!-- <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?> -->

                                        <a style="font-size:8px;" class="btn btn-sm btn-primary" href="<?php echo e(route('brand.edit', $brand->id)); ?>"><i class="fas fa-edit"></i></a>
                                        <!-- <button style="font-size:8px;" name="btndelete" data-toggle="tooltip" title="Delete" type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this items : <?php echo e($brand->bsName); ?> ?');"><i class="fas fa-trash"></i></button> -->
                                    </form>
                                </td>

                            </tr>
                        </tbody>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-4" style="font-size:13px;">
        <div class="card shadow">
            <div class="card-header card-header bg-dark text-light"><i class="fas fa-user"></i> List User </div>
            <div class="card-body">
                <div class="table-responsive">

                    <table class="table table-border datatable">


                        <thead>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Roles</th>



                            <th width="200px">Action</th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>

                                <td><?php echo e($room->id); ?></td>
                                <td><?php echo e($room->name); ?></td>
                                <td><?php echo e($room->username); ?></td>
                                <td><?php echo e($room->email); ?></td>
                                <td><?php echo e($room->roles); ?></td>
                                <td>
                                    <form action="<?php echo e(route('user.destroy', $room->id)); ?>" method="POST">

                                        <a style="font-size:8px;" class="btn btn-sm btn-primary" href="<?php echo e(route('user.edit', $room->id)); ?>"><i class="fas fa-edit"></i></a>
                                        <!-- <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        
                                        <button style="font-size:8px;" name="btndelete" data-toggle="tooltip" title="Delete" type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this items : <?php echo e($room->username); ?> ?');"><i class="fas fa-trash"></i></button> -->
                                    </form>
                                </td>



                            </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>






                    </table>
                </div>
            </div>

        </div>
    </div>
    
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dash.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tp\web_file\resources\views/dashboard/index.blade.php ENDPATH**/ ?>