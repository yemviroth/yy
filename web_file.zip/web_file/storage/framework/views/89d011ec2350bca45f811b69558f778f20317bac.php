<?php $__env->startSection('title'); ?>
USER
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="" style="font-size:13px;">

   
        <div class="container">
            <div class="col-8">
                <div class="row">
                    <div class="  pt-2 pb-1">
                        <a href="<?php echo e(route('user.create')); ?>" class="btn btn-sm btn-success"><i class="fas fa-plus-square"></i> បង្កើតអ្នកប្រើថ្មី</a>
                   </div>
               </div>
            </div>

            <div class="card shadow">
                <div class="card-header card-header bg-dark text-light"><i class="fas fa-user"></i> បញ្ជីអ្នកប្រើ  </div>
                <div class="card-body">
                    <div class="table-responsive">

                        <table class="table table-border datatable">


                            <thead>
                                <th>#</th>
                                <th>Name</th>
                                <th>Username</th>
                                <th>Email</th>
                                
                                <th width="200px">Action</th>
                            </thead>
                            <tbody>
                                <?php $id=0;?>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>

                                    <td><?php echo e(++$id); ?></td>
                                    <td><?php echo e($room->name); ?></td>
                                    <td><?php echo e($room->username); ?></td>
                                    <td><?php echo e($room->email); ?></td>
                                   


                                   

                                    <td>
                                        <form action="<?php echo e(route('user.destroy', $room->id)); ?>" method="POST">
                                            
                                            <a style="font-size:8px;" class="btn btn-sm btn-primary" href="<?php echo e(route('user.edit', $room->id)); ?>"><i class="fas fa-edit"></i></a>
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            
                                            <!-- <button style="font-size:8px;" name="btndelete" data-toggle="tooltip" title="Delete" type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this items : <?php echo e($room->username); ?> ?');"><i class="fas fa-trash"></i></button> -->
                                        </form>
                                    </td>



                                </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>






                        </table>
                    </div>
                </div>

            </div>




        </div>
    


</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dash.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tp\web_file\resources\views/user/index.blade.php ENDPATH**/ ?>