<?php
  $mytitle = " - Tropicana Resort & Casino";    
?>
<?php $__env->startSection('meta'); ?>
  <meta content='http://tropicanacasinopoipet.com/' property='og:url'/>
  <meta content='Tropicana Casino Poipet' property='og:title'/>    
  <meta content="<?php echo e(Config::get('mysiteVars.meta_service.'. session()->get('LANG'))); ?>" name='description'/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
<?php echo e(Config::get('mysiteVars.menu_gallerys.'. session()->get('LANG'))); ?><?php echo e($mytitle); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<!-- navigator -->
<section>
  <div class="container-fluid">
    <div class="row">
      <div class="col">
        <p class="navigator-link" style="font-weight: bold;"><a href="<?php echo e(route('home.index')); ?>"><?php echo e(Config::get('mysiteVars.menu_home.'. session()->get('LANG'))); ?></a><i class="fas fa-caret-right pl-1 pr-1"></i><a href="<?php echo e(route('gallery.index')); ?>" style="color: #057374"><?php echo e(Config::get('mysiteVars.menu_gallerys.'. session()->get('LANG'))); ?></a></p>
      </div>
    </div>
  </div>
</section>
<!-- end of navigator -->

<!-- service -->

<section class="pl-5 pr-5 pb-5 pt-1">
  <div class="container-fluid">
    <div class="row  pb-5">
      <div class="col text-center">        
        <h2><b><?php echo e(Config::get('mysiteVars.menu_gallerys.'. session()->get('LANG'))); ?></b></h2>
        <hr align="center" width="70px" style="background-color: #ccc; height: 0.01em">
      </div>
    </div>

 

    <div class="row pb-1">
      <div class="col-sm pl-1">
        <div class="card shadow">
          <div class="card-header bg-primary text-white text-center h4">
            <?php echo e(Config::get('mysiteVars.service_fontoffice_title.'. session()->get('LANG'))); ?>

          </div>
          <div class="card-body">
            <div class="gallery"> 

              <?php for($fo=1; $fo<=4; $fo++): ?>
                    <a href="<?php echo e(asset('images/gallery/Front Office/fo'.$fo.'.jpg')); ?>" class="big">
                      <img class="img-fluid" src="<?php echo e(asset('images/gallery/Front Office/thumbnail/fo'.$fo.'.jpg')); ?>" alt="" title="Tropicana <?php echo e(Config::get('mysiteVars.service_fontoffice_title.'. session()->get('LANG'))); ?>">
                    </a>
              <?php endfor; ?>
              

            </div>
          </div>
        </div>
      </div>
    </div>


    <div class="row pt-3">
      <div class="col-sm pl-1">
        <div class="card shadow">
          <div class="card-header bg-primary text-light text-center h4">
            <?php echo e(Config::get('mysiteVars.service_healtybar_title.'. session()->get('LANG'))); ?>

          </div>
          <div class="card-body">
            <div class="gallery"> 

              <?php for($ht=1; $ht<=13; $ht++): ?>
                    <a href="<?php echo e(asset('images/gallery/HEALTHY BAR/ht'.$ht.'.jpg')); ?>" class="big">
                      <img class="img-fluid" src="<?php echo e(asset('images/gallery/HEALTHY BAR/thumbnail/ht'.$ht.'.jpg')); ?>" alt="" title="Tropicana <?php echo e(Config::get('mysiteVars.service_healtybar_title.'. session()->get('LANG'))); ?>">
                    </a>
              <?php endfor; ?>

            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row pt-3">
      <div class="col-sm pl-1">
        <div class="card shadow">
          <div class="card-header bg-primary text-light text-center h4">
            <?php echo e(Config::get('mysiteVars.service_restaurant_title.'. session()->get('LANG'))); ?>

          </div>
          <div class="card-body">
            <div class="gallery"> 

              <?php for($Restaurant=1; $Restaurant<=9; $Restaurant++): ?>
                    <a href="<?php echo e(asset('images/gallery/RESTAURANT/Restaurant'.$Restaurant.'.jpg')); ?>" class="big">
                      <img class="img-fluid" src="<?php echo e(asset('images/gallery/RESTAURANT/thumbnail/Restaurant'.$Restaurant.'.jpg')); ?>" alt="" title="Tropicana <?php echo e(Config::get('mysiteVars.service_restaurant_title.'. session()->get('LANG'))); ?>">
                    </a>
              <?php endfor; ?>

            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row pt-3">
      <div class="col-sm pl-1">
        <div class="card shadow">
          <div class="card-header bg-primary text-light text-center h4">
            <?php echo e(Config::get('mysiteVars.service_spa_title.'. session()->get('LANG'))); ?>

          </div>
          <div class="card-body">
            <div class="gallery"> 

              <?php for($SPA=1; $SPA<=13; $SPA++): ?>
                    <a href="<?php echo e(asset('images/gallery/SPA/SPA'.$SPA.'.jpg')); ?>" class="big">
                      <img class="img-fluid" src="<?php echo e(asset('images/gallery/SPA/thumbnail/SPA'.$SPA.'.jpg')); ?>" alt="" title="Tropicana <?php echo e(Config::get('mysiteVars.service_spa_title.'. session()->get('LANG'))); ?>">
                    </a>
              <?php endfor; ?>

            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row pt-3">
      <div class="col-sm pl-1">
        <div class="card shadow">
          <div class="card-header bg-primary text-light text-center h4">
            <?php echo e(Config::get('mysiteVars.service_gym_title.'. session()->get('LANG'))); ?>

          </div>
          <div class="card-body">
            <div class="gallery"> 

              <?php for($GYM=1; $GYM<=8; $GYM++): ?>
                    <a href="<?php echo e(asset('images/gallery/GYM/GYM'.$GYM.'.jpg')); ?>" class="big">
                      <img class="img-fluid" src="<?php echo e(asset('images/gallery/GYM/thumbnail/GYM'.$GYM.'.jpg')); ?>" alt="" title="Tropicana <?php echo e(Config::get('mysiteVars.service_gym_title.'. session()->get('LANG'))); ?>">
                    </a>
              <?php endfor; ?>

            </div>
          </div>
        </div>
      </div>
    </div>


    <div class="row pt-3">
      <div class="col-sm pl-1">
        <div class="card shadow">
          <div class="card-header bg-primary text-light text-center h4">
            <?php echo e(Config::get('mysiteVars.service_snooker_title.'. session()->get('LANG'))); ?>

          </div>
          <div class="card-body">
            <div class="gallery"> 

              <?php for($ht=1; $ht<=13; $ht++): ?>
                  
                
                    <a href="<?php echo e(asset('images/gallery/SNOOKER/sk'.$ht.'.jpg')); ?>" class="big">
                   
                        <img class="img-fluid" src="<?php echo e(asset('images/gallery/SNOOKER/thumbnail/sk'.$ht.'.jpg')); ?>" alt="" title="Tropicana <?php echo e(Config::get('mysiteVars.service_snooker_title.'. session()->get('LANG'))); ?>">
                    </a>

              <?php endfor; ?>

            </div>
          </div>
        </div>
      </div>
    </div>











  </div>
</section>

<!-- end service -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('js/simple-lightbox.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/simple-lightbox.jquery.min.js')); ?>"></script>

    <script>
    // As A Vanilla JavaScript Plugin
var gallery = new SimpleLightbox('.gallery a', { 
  
    /* options */ 
});


    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tp\web_file\resources\views/gallery/index.blade.php ENDPATH**/ ?>