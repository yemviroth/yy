<div class=" d-sm-none list pt-3 text-center text-kh font-weight-bold">
    <a class="pl-4 <?php echo e((\Request::route()->getName()=='about.index' ? 'active' : '')); ?>" href="<?php echo e(route('about.index')); ?>">
        Branch Story
    </a>

    <a class="pl-4 <?php echo e((\Request::route()->getName()=='ingrediant' ? 'active' : '')); ?>" href="<?php echo e(route('brand.index')); ?>">
        ដំណាងចែកចាយ
    </a>

    <a class="pl-4 <?php echo e((\Request::route()->getName()=='ingrediant' ? 'active' : '')); ?>" href="<?php echo e(route('ingrediant')); ?>">គ្រឿងផ្សំ</a>
</div><?php /**PATH C:\xampp\htdocs\tp\web_file\resources\views/layouts/mobile-about-link.blade.php ENDPATH**/ ?>