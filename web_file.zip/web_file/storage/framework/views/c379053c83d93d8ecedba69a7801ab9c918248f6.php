<?php $__env->startSection('content'); ?>

<div class="w-100 d-none d-md-block pt-5"></div>
<section class="" style="background: #fff">
  <div class="pt-4 d-none d-lg-block"></div>
  <div class="header-title pt-4 text-center">ដំណាងចែកចាយ</div>

</section>

<div class="wrapper pt-5">
  <div class="container-fluid">

    <section>

      <div class="row">

        <div class="col-sm-12 col-md-6 col-xl-3 pb-3">
          <div class="col-12 align-self-center">
            <img class="shadow card-img-top rounded-circle text-center" src="<?php echo e(asset('images/nary.jpg')); ?>" alt="Card image cap" style="height: 300x;">
          </div>
          <div class="col-12 align-self-center text-center">
            <hr>
            <b>
              <h4>បោយប៉ែត</h4>
            </b>
            ​<p> ឈ្មោះ : <strong> Nary</strong> </p>
            <p><i class="fas fa-map-marker-alt"></i> : <strong> បោយប៉ែត</strong> </p>
            <p><i class="fas fa-phone-square-alt"></i> : <strong> 069566845 / 093 544 869</strong> </p>
            <p><i class="fab fa-facebook fa-1x"></i> : <strong> Nary Online Shop</strong> </p>
            <p><i class="fab fa-instagram-square"></i> : <strong> Nary_Official</strong> </p>
            <hr>
          </div>
        </div>

        <div class="col-sm-12 col-md-6 col-xl-3 pb-3">
          <div class="col-12 align-self-center">
            <img class="shadow card-img-top rounded-circle text-center" src="<?php echo e(asset('images/nary.jpg')); ?>" alt="Card image cap" style="height: 300x;">
          </div>
          <div class="col-12 align-self-center text-center">
            <hr>
            <b>
              <h4>បោយប៉ែត</h4>
            </b>
            ​<p> ឈ្មោះ : <strong> Nary</strong> </p>
            <p>អស័យដ្ឋាន : <strong> បោយប៉ែត</strong> </p>
            <p>លេខទូរស័ព្ទ : <strong> 069566845 / 093 544 869</strong> </p>
            <p>Page : <strong> Nary Online Shop</strong> </p>
            <p>IG : <strong> Nary_Official</strong> </p>
            <hr>
          </div>
        </div>

        <div class="col-sm-12 col-md-6 col-xl-3 pb-3">
          <div class="col-12 align-self-center">
            <img class="shadow card-img-top rounded-circle text-center" src="<?php echo e(asset('images/nary.jpg')); ?>" alt="Card image cap" style="height: 300x;">
          </div>
          <div class="col-12 align-self-center text-center">
            <hr>
            <b>
              <h4>បោយប៉ែត</h4>
            </b>
            ​<p> ឈ្មោះ : <strong> Nary</strong> </p>
            <p>អស័យដ្ឋាន : <strong> បោយប៉ែត</strong> </p>
            <p>លេខទូរស័ព្ទ : <strong> 069566845 / 093 544 869</strong> </p>
            <p>Page : <strong> Nary Online Shop</strong> </p>
            <p>IG : <strong> Nary_Official</strong> </p>
            <hr>
          </div>
        </div>

        <div class="col-sm-12 col-md-6 col-xl-3 pb-3">
          <div class="col-12 align-self-center">
            <img class="shadow card-img-top rounded-circle text-center" src="<?php echo e(asset('images/nary.jpg')); ?>" alt="Card image cap" style="height: 300x;">
          </div>
          <div class="col-12 align-self-center text-center">
            <hr>
            <b>
              <h4>បោយប៉ែត</h4>
            </b>
            ​<p> ឈ្មោះ : <strong> Nary</strong> </p>
            <p>អស័យដ្ឋាន : <strong> បោយប៉ែត</strong> </p>
            <p>លេខទូរស័ព្ទ : <strong> 069566845 / 093 544 869</strong> </p>
            <p>Page : <strong> Nary Online Shop</strong> </p>
            <p>IG : <strong> Nary_Official</strong> </p>
            <hr>
          </div>
        </div>

      </div>

    </section>
  </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tp\web_file\resources\views/branch/index.blade.php ENDPATH**/ ?>