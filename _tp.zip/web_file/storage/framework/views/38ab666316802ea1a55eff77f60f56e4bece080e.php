<?php $__env->startSection('content'); ?>

<div class="w-100 d-none d-md-block pt-5"></div>
<section style="background: #fff">
    <div class="pt-4 d-none d-lg-block"></div>
    <div class="header-title pt-4 text-center">ដំណាងចែកចាយ</div>

</section>

<div class="wrapper pt-5">
    <div class="container">

        <section>

            <div class="row">
                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="col-md-4">
                    <div class="card col-sm-12 ml-2 mb-3">
                        <img class="card-img-top img-fluid"
                            src="<?php if($brand->dsPhoto == ''): ?><?php echo e(asset('images/profile/noImg.png')); ?><?php else: ?><?php echo e(asset('images/profile/'.$brand->dsPhoto)); ?><?php endif; ?>"
                            alt="Card image cap">
                        <div class="card-body">
                            <hr>
                         
                            <h4 class="card-title text-center"><?php echo e($brand->dsLocation); ?></h4>
                            ​<p> ឈ្មោះ : <strong> <?php echo e($brand->dsName); ?></strong> </p>
                            <p>អស័យដ្ឋាន : <strong> <?php echo e($brand->dsAddress); ?></strong> </p>
                            <p>លេខទូរស័ព្ទ : <strong> <?php echo e($brand->dsPhone); ?></strong> </p>
                            <p>Page : <strong> <?php echo e($brand->dsFb); ?></strong> </p>
                            <p>IG : <strong> <?php echo e($brand->dsIg); ?></strong> </p>
                            <hr>
                        </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="card col-sm-12 ml-2 mb-3">
                        <img class="card-img-top img-fluid"
                            src="<?php if($brand->dsPhoto == ''): ?><?php echo e(asset('images/profile/noImg.png')); ?><?php else: ?><?php echo e(asset('images/profile/'.$brand->dsPhoto)); ?><?php endif; ?>"
                            alt="Card image cap">
                        <div class="card-body">
                            <hr>
                         
                            <h4 class="card-title text-center"><?php echo e($brand->dsLocation); ?></h4>
                            ​<p> ឈ្មោះ : <strong> <?php echo e($brand->dsName); ?></strong> </p>
                            <p>អស័យដ្ឋាន : <strong> <?php echo e($brand->dsAddress); ?></strong> </p>
                            <p>លេខទូរស័ព្ទ : <strong> <?php echo e($brand->dsPhone); ?></strong> </p>
                            <p>Page : <strong> <?php echo e($brand->dsFb); ?></strong> </p>
                            <p>IG : <strong> <?php echo e($brand->dsIg); ?></strong> </p>
                            <hr>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





            </div>

        </section>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tp\web_file\resources\views/brand/index.blade.php ENDPATH**/ ?>