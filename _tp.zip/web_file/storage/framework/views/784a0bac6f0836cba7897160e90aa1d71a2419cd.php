<?php $__env->startSection('title'); ?>
TROPICANA - ROOMS
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>   

<div class="container pt-4">
     



    <div class="card">
  <div class="card-header bg-me text-light h4">
    <i class="fas fa-plus-square"></i> New Rooms Main
  </div>
  <div class="card-body">
    <!-- <h5 class="card-title">Special title treatment</h5> -->
        
    
        <form action="<?php echo e(route('rooms.main.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="container">
                    <div class="col-md-12 p-1">
                        <div class="row">
                                <div class="col-12">
                                        <?php if($errors->any()): ?>
                                        <div class="alert alert-danger alert-dismissible fade show"  role="alert"><strong>Whoops</strong> there where some problems with your input.
                                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                              </button>
                                            </div>
                                            
                                            
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-sm-12 col-md-4 col-lg-4 col-xl-4">
                                        <strong>Room Name :</strong>
                                       
    
                                        <input type="text"  value="<?php echo e(old('name')); ?>" name="name" id="name" class="form-control <?php if($errors->has('name')): ?> is-invalid <?php endif; ?> " placeholder="" autocomplete="off" >
                                        <?php if($errors->has('name')): ?>
                                            <div class="invalid-feedback"> <strong><?php echo e($errors->first('name')); ?></strong></div>
                                        <?php endif; ?>
                                    </div>

                                    <div class="w-100"></div>                                    

                                    <div id="dvPreview">
                                    </div>

                                    
                                      
                                    <div class="w-100"></div>
                                    <div class="col-sm-12 col-md-4 col-lg-4 col-xl-4">
                                        <strong>Photo1 (Main):</strong>                                    
                                        <input type="file" name="filephoto1" class="form-control" id="filephoto1">
                                        <?php if($errors->has('filephoto1')): ?>
                                            <div class="error"> <strong><?php echo e($errors->first('filephoto1')); ?></strong></div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="w-100"></div>
                                    <div class="col-sm-12 col-md-4 col-lg-4 col-xl-4">
                                        <strong>Photo2:</strong>                                    
                                        <input type="file" name="filephoto2" class="form-control" id="filephoto2">
                                        <?php if($errors->has('filephoto1')): ?>
                                            <div class="error"> <strong><?php echo e($errors->first('filephoto2')); ?></strong></div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="w-100"></div>
                                    <div class="col-sm-12 col-md-4 col-lg-4 col-xl-4">
                                        <strong>Photo3:</strong>                                    
                                        <input type="file" name="filephoto3" class="form-control" id="filephoto3">
                                        <?php if($errors->has('filephoto3')): ?>
                                            <div class="error"> <strong><?php echo e($errors->first('filephoto3')); ?></strong></div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="w-100"></div>
                                    <div class="col-sm-12 col-md-4 col-lg-4 col-xl-4">
                                        <strong>Photo4:</strong>                                    
                                        <input type="file" name="filephoto4" class="form-control" id="filephoto4">
                                        <?php if($errors->has('filephoto4')): ?>
                                            <div class="error"> <strong><?php echo e($errors->first('filephoto4')); ?></strong></div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="w-100"></div>
                                    <div class="col-sm-12 col-md-4 col-lg-4 col-xl-4">
                                        <strong>Photo5:</strong>                                    
                                        <input type="file" name="filephoto5" class="form-control" id="filephoto5">
                                        <?php if($errors->has('filephoto5')): ?>
                                            <div class="error"> <strong><?php echo e($errors->first('filephoto5')); ?></strong></div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="w-100"></div>
                                    <div class="col-sm-12 col-md-4 col-lg-4 col-xl-4">
                                        <strong>Photo6:</strong>                                    
                                        <input type="file" name="filephoto6" class="form-control" id="filephoto6">
                                        <?php if($errors->has('filephoto6')): ?>
                                            <div class="error"> <strong><?php echo e($errors->first('filephoto6')); ?></strong></div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="w-100"></div>
                                    <div class="col-sm-12 col-md-4 col-lg-4 col-xl-4">
                                        <strong>Photo7:</strong>                                    
                                        <input type="file" name="filephoto7" class="form-control" id="filephoto7">
                                        <?php if($errors->has('filephoto7')): ?>
                                            <div class="error"> <strong><?php echo e($errors->first('filephoto7')); ?></strong></div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="w-100"></div>         

                                    <div class="col-sm-12 col-md-4 col-lg-4 col-xl-4">
                                        <strong>Published:</strong>
                                        <select  name="published" class="form-control">
                                          <option <?php if(old('published') =='Yes'): ?> <?php echo e('selected'); ?> <?php endif; ?> value="Yes">Yes</option>
                                          <option <?php if(old('published') =='No'): ?> <?php echo e('selected'); ?> <?php endif; ?> value="No" >No</option>
                                          
                                        </select>
                                      </div>
                                      
                                    
                                    <div class="w-100"></div>
                                 
                                    <div class="col-md-12  mt-2">
                                          <hr>
                                        <a href="<?php echo e(route('rooms.main')); ?>" class="btn btn-success">Back</a>
                                        <button type="submit" class="btn btn-primary">Submit</button>
                                    </div>
                        </div>
                            
                    </div>
            </div>
               
                
                    
                
                    
          
        </div>

    
    </form>
    


  </div>
</div>

</div>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script language="javascript" type="text/javascript">
$(function () {
    $("#fileupload").change(function () {
        $("#dvPreview").html("");
        var regex = /^([a-zA-Z0-9\s_\\.\-:])+(.jpg|.jpeg|.gif|.png|.bmp)$/;
        if (regex.test($(this).val().toLowerCase())) {
            if ($.browser.msie && parseFloat(jQuery.browser.version) <= 9.0) {
                $("#dvPreview").show();
                $("#dvPreview")[0].filters.item("DXImageTransform.Microsoft.AlphaImageLoader").src = $(this).val();
            }
            else {
                if (typeof (FileReader) != "undefined") {
                    $("#dvPreview").show();
                    $("#dvPreview").append("<img />");
                    var reader = new FileReader();
                    reader.onload = function (e) {
                        $("#dvPreview img").attr("src", e.target.result);
                    }
                    reader.readAsDataURL($(this)[0].files[0]);
                } else {
                    alert("This browser does not support FileReader.");
                }
            }
        } else {
            alert("Please upload a valid image file.");
        }
    });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tp\web_file\resources\views/roommain/create.blade.php ENDPATH**/ ?>