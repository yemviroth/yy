<?php $__env->startSection('title'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<?php $__env->startComponent('layouts.mobile-about-link'); ?>

<?php echo $__env->renderComponent(); ?>
<div class="pt-5">
    <img class="w-100" src="<?php echo e(asset('images/brand_story.jpg')); ?>" alt="">
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tp\web_file\resources\views/about/about.blade.php ENDPATH**/ ?>