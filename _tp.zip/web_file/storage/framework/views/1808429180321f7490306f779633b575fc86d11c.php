<?php $__env->startSection('title'); ?>
TheYeon Cambodia
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>   

<div class="container p-4">
    <div class="row justify-content-center">
        <div class="col-md-8 ">
                <div class="modal-content shadow m=3">
                    <div class="modal-header modal-md  text-light bg-dark">
                    
                        <p class="modal-title">
                        <span><i class="fas fa-edit"></i></span><span class="ml-2">Edit Sub Category</span>
                        </p>
                    </div>
                    <form action="<?php echo e(route('category/subcategory.update',$edit->subCateId)); ?>" method="POST" enctype="multipart/form-data" class="">
                    <div class="modal-body">
                            
                    <?php echo e(csrf_field()); ?>

                     <?php echo e(method_field('PUT')); ?>


                                         <div class="form-group row">
                                            <label for="cateId" class="col-md-3 form-label text-md-right">Category :</label>
                                            <div class="col-md-9">
                                                <select name="cateId" id="" class="form-control">
                                                     <?php $__currentLoopData = $cates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($cate->cateId); ?>" <?php if($cate->cateId == $edit->cateId): ?> selected <?php endif; ?>><?php echo e($cate->cateName); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>                                            
                                        </div>

                                        <div class="form-group row">
                                            <label for="subCateName" class="col-md-3 form-label text-md-right">Sub Name :</label>
                                            <div class="col-md-9">
                                                <input type="text" id="subCateName" class="form-control" name="subCateName" value="<?php echo e($edit->subCateName); ?>" required>
                                            </div>                                            
                                        </div>
                                        <div class="form-group row">
                                            <label for="cateOrderBy" class="col-md-3 form-label text-md-right">In Order :</label>
                                            <div class="col-md-9">
                                                <input type="text" id="cateOrderBy" class="form-control" name="cateOrderBy" value="<?php echo e($edit->cateOrderBy); ?>">
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label for="cateDescription" class="col-md-3 col-form-label text-md-right">Description:</label>
                                            <div class="col-md-9">
                                                
                                                <textarea name="cateDescription" class="form-control" id=""  rows="3"><?php echo e($edit->cateDescription); ?></textarea>
                                            </div>
                                        </div>
                                            
                            
                    </div>
                    <div class="modal-footer">
                            <a class="btn  btn-secondary text-md-left" href="<?php echo e(route('category.list')); ?>">Back</a>
                                        
                           <button class="btn  btn-success text-md-left" type="submit">Update</button>
                    </div>
                    </form>
                </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dash.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tp\web_file\resources\views/category/subcategory/edit.blade.php ENDPATH**/ ?>