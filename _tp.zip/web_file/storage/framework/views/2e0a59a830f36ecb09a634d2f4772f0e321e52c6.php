<?php $__env->startSection('content'); ?>



<!-- <?php if($message = Session::get('success')): ?>
<div id="malert" class="alert alert-success alert-dismissible fade show" role="alert"><?php echo e($message); ?>

    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>

<?php endif; ?> -->



<div class="">
    <div class="col-md-10 mx-auto ml-0">



        <div class="">
            <div class=" ml-0 mr-0 pt-2 pb-1">
                <a href="<?php echo e(route('category.create')); ?>" class="btn btn-success btn-sm"><i
                        class="fas fa-plus-square"></i>បន្ថែមប្រភេទទំនិញ</a>
                <a href="<?php echo e(route('category/subcategory.create')); ?>" class="btn btn-info btn-sm"><i
                        class="fas fa-plus-square"></i>បន្ថែមប្រភេទទំនិញរង</a>
            </div>

        </div>

        <div class="">
            <div class="card">
                <h6 class="card-header bg-dark text-light">
                    <i class="fas fa-clipboard-list"></i><span class="ml-2">បញ្ចីប្រភេទទំនិញ</span>
                </h6>
                <div class="card-body shadow">
                    <div class="table-responsive">
                        <table class="table table-border datatable" style="font-size:14px;" id="">

                            <thead class="">
                                <th>ប្រភេទផលិតផល</th>
                                <th>ប្រភេទរងទំនិញ</th>
                                <th>តម្រៀប</th>
                                <th>បរិយាយ</th>
                                <th>សកម្មភាព</th>

                            </thead>
                            <?php $__currentLoopData = $cates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tbody id="">
                                <tr style="">
                                    <td>
                                        <?php echo e($cate->cateName); ?>

                                    </td>
                                    <td>

                                        <?php $__currentLoopData = $subcates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($cate->cateId == $subcate->cateId): ?>
                                        <table class="table table-sm table-striped" style="font-size:14px;">
                                            <?php if(isset($subcates)): ?>
                                            <tr class="table-secondary">
                                                <th>ឈ្មោះប្រភេទរង</th>
                                                <th>សកម្មភាព</th>
                                            </tr>
                                            <?php endif; ?>



                                            <tr>

                                                <td><?php echo e($subcate->subCateName); ?></td>
                                                <td>
                                                    <form
                                                        action="<?php echo e(route('category/subcategory.destroy',$subcate->subCateId)); ?>"
                                                        method="POST">

                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>

                                                        <a href="<?php echo e(route('category/subcategory.edit', $subcate->subCateId)); ?>"
                                                            class="btn btn-sm btn-warning"><i
                                                                class="fas fa-edit"></i></a>
                                                        <button type="submit" class="btn btn-sm btn-danger"
                                                            onclick="return confirm('Are you sure you want to delete this items : <?php echo e($subcate->subCateName); ?> ?');"><i
                                                                class="fas fa-trash"></i></button>
                                                    </form>
                                                </td>
                                            </tr>
                                        </table>
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





                                    </td>
                                    <td><?php echo e($cate->cateOrderBy); ?></td>
                                    <td><?php echo e($cate->cateDescription); ?></td>


                                    <td>
                                        <form action="<?php echo e(route('category.destroy',$cate->cateId)); ?>" method="POST">

                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>

                                            <a style="" class="btn btn-sm btn-primary"
                                                href="<?php echo e(route('category.edit', $cate->cateId)); ?>"><i
                                                    class="fas fa-edit"></i></a>
                                            <button style="" name="btndelete" data-toggle="tooltip" title="Delete"
                                                type="submit" class="btn btn-sm btn-danger"
                                                onclick="return confirm('Are you sure you want to delete this items : <?php echo e($cate->cateName); ?> ?');"><i
                                                    class="fas fa-trash"></i></button>
                                        </form>
                                    </td>

                                </tr>
                            </tbody>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<script>
$(document).ready(function() {
    $("#myInput").on("keyup", function() {
        var value = $(this).val().toLowerCase();
        $("#myTable tr").filter(function() {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
        });
    });
});
</script>
<?php echo $__env->make('layouts.dash.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tp\web_file\resources\views/category/list.blade.php ENDPATH**/ ?>